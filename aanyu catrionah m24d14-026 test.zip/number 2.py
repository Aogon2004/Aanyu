def print_multiplication_table(number):
    for i in range(1,13) : #loop from 1 to 12
        print(f"{number} x {i} = {number * i}")
num = int(input("Enter a number: "))
print_multiplication_table(num)