def get_even_numbers(numbers):
    even_numbers=[num for num in numbers if num %2== 0]
    return even_numbers
input_list = [8, 7, 6, 1, 2, 3, 9, 11, 5, 4]
output_list = get_even_numbers(input_list)
print("Even numbers:",output_list)