def find_largest_number(numbers) :  
    #Initialize the largest number with the first element in the list
      largest = numbers[0]

    #Iterate through the list to find the largest numnber
    for number in numbers:
        if number > largest :
            largest = number
return largest
input_list = [1, 5, 6, 7, 2, 8, 3]
largest_number = find_largest_number(input_list)
print("The largest number is:", largest_number)