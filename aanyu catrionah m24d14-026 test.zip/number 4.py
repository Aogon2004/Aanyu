def is_same_string(input_string,  compare_string) :
    # Compare the two strings
    if input_string == compare_string:
        return True
    
        return False
    input_string =input("Enter the first string: ")
    compare_string = input("Enter the second string to compare: ")

    if is_same_string(input_string, compare_string):
        print("The strings are the same.")
    else:
        print("The strings are different.")