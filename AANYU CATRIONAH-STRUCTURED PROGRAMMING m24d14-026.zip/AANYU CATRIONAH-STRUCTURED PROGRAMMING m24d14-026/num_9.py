def km_miles():
    print("This program converts kilometers to miles.")
    kilometers = eval(input("Enter the distance in kilometers: "))
    miles = kilometers * 0.62
    
    print(kilometers, "kilometers is approximately" ,miles, "miles.")

km_miles()
