def fibonacci (n):
    """Calculates the nth fibonacci number using an iterative approach."""
    if n< 0:
        raise ValueError("n must be non-negative")
    elif n == 0:
        return 0
    elif n == 1:
        return 1
    fib_n_minus_1, fib_n_minus_2 = 1, 0
    for _ in range(2, n+1):
        fib_n=fib_n_minus_1 + fib_n_minus_2
        fib_n_minus_2, fib_n_minus_1 = fib_n_minus_1, fib_n 
        return fib_n
    if __name__=="__main__":
        while True:
            try:
                n = int(input("Enter a non-negative integer(or 'q' to quit):"))
                if n<0:
                    raise ValueError("n must be non-negative")
                elif n == 0:
                    break
                result = fibonacci(n)
                print(f"The {n}th Fibonacci number is: {result}")
            except ValueError:
                print("Invalid input.Please enter a non-negative integer.")
            except KeyboardInterrupt:
                print("\nExiting...")
                break